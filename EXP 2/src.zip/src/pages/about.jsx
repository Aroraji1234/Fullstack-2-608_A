import React from 'react'

const about = () => {
  return (
    <div>
      <h1>About</h1>
      <h1>Piyush's About Page</h1>
    </div>
  )
}

export default about
