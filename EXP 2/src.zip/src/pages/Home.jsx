import React from 'react'

const Home = () => {
  return (
    <div>
        <h1>Home Page</h1>
      <h1>UID:23BCS12231</h1>
      <h1>Piyush Arora</h1>
    </div>
  )
}

export default Home
